package com.kelaniya.uni.calc.v6;

/**
 * Created by asankah on 12/13/17.
 */
public interface UI {
    void show(String message);
}
