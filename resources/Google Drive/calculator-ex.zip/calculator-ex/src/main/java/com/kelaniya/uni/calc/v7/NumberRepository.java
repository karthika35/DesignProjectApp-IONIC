package com.kelaniya.uni.calc.v7;

/**
 * Created by asankah on 12/13/17.
 */
public interface NumberRepository {
    int[] read();
}
