package com.kelaniya.uni.calc.v3;

/**
 * Created by asankah on 12/13/17.
 */
public interface ArgsParser {
    String getOperation();
}
