package com.kelaniya.uni.calc.v7;

import com.kelaniya.uni.calc.v7.operations.Operation;
import com.kelaniya.uni.calc.v7.operations.OperationsFactory;

/**
 * Created by asankah on 12/6/17.
 */
public class Main {
    public static void main(String[] args) {


        NumberRepository numberRepository = new TextFileNumberRespository();
        ArgsParser argsParser = new CMDArgsParser(args);
        OperationsFactory operationsFactory = new OperationsFactory();
        UI ui = new CmdUI();

        CalculatorApp calculatorApp = new
                CalculatorApp(args,numberRepository,
                argsParser,operationsFactory,ui);
        calculatorApp.run();

    }
}
