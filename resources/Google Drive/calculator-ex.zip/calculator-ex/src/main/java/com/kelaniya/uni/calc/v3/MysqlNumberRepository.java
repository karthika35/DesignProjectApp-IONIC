package com.kelaniya.uni.calc.v3;

/**
 * Created by asankah on 12/13/17.
 */
public class MysqlNumberRepository implements NumberRepository {
    public int[] read(){
        //todo read from mysql db
        int[] numbers = {25,32};

        return numbers;
    }
}
