package com.kelaniya.uni.calc.v5.operations;

/**
 * Created by asankah on 12/13/17.
 */
public class AddOperation implements Operation {
    public double perform(int a, int b) {
        return a + b;
    }
}
