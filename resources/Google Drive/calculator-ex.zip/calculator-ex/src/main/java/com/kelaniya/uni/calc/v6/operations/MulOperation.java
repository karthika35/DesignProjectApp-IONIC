package com.kelaniya.uni.calc.v6.operations;

/**
 * Created by asankah on 12/13/17.
 */
public class MulOperation implements Operation {
    public double perform(int a, int b) {
        return a*b;
    }
}
