package com.kelaniya.uni.calc.v7;

/**
 * Created by asankah on 12/13/17.
 */
public class CmdUI implements UI {

    public void show(String message) {
        System.out.println(message);
    }
}
