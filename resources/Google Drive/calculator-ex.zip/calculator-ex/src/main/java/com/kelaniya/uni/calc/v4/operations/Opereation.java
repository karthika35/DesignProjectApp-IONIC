package com.kelaniya.uni.calc.v4.operations;

/**
 * Created by asankah on 12/13/17.
 */
public interface Opereation {
    double perform(int a, int b);
}
