package com.kelaniya.uni.calc.v2;

/**
 * Created by asankah on 12/13/17.
 */
public interface NumberRepository {
    int[] read();
}
