package com.kelaniya.uni.calc.v7;

import com.kelaniya.uni.calc.v7.operations.Operation;
import com.kelaniya.uni.calc.v7.operations.OperationsFactory;

/**
 * Created by asankah on 12/13/17.
 */
public class CalculatorApp {

    private final String[] args;
    private final NumberRepository numberRepository;
    private final ArgsParser argsParser;
    private final OperationsFactory operationsFactory;
    private final UI ui;

    public CalculatorApp(String args[], NumberRepository numberRepository, ArgsParser argsParser,
                         OperationsFactory operationsFactory,UI ui ) {
        this.args = args;
        this.numberRepository = numberRepository;
        this.argsParser = argsParser;
        this.operationsFactory = operationsFactory;
        this.ui = ui;
    }

    void run(){
        int[] numbers = numberRepository.read();
        String operation = argsParser.getOperation();
        double result = 0;
        Operation operationObj = operationsFactory.getInstance(operation);
        result = operationObj.perform(numbers[0],numbers[1]);
        ui.show("The result is " + result);
    }

}
