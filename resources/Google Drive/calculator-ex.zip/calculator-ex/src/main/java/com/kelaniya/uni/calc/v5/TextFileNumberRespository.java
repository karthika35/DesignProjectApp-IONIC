package com.kelaniya.uni.calc.v5;

/**
 * Created by asankah on 12/13/17.
 */
public class TextFileNumberRespository implements NumberRepository {

    public int[] read(){

        //todo: read text file

        int[] numbers = {25,32}; //todo: numbers should be read from  a text file.

        return numbers;

    }

}
