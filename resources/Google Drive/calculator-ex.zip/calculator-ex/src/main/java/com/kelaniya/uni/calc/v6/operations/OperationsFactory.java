package com.kelaniya.uni.calc.v6.operations;

/**
 * Created by asankah on 12/13/17.
 */
public class OperationsFactory {

    public Operation getInstance(String operation){

        Operation operationObj = null;

        if ("add".equals(operation)){
            operationObj = new AddOperation();
        }
        else if ("mul".equals(operation)){
            operationObj = new MulOperation();
        }else if ("div".equals(operation)){
            operationObj = new DivOperation();
        }else {
            //todo: handle this exception properly
            throw new RuntimeException("Operation " + operation + " is not implemented");
        }

        return operationObj;
    }

}
