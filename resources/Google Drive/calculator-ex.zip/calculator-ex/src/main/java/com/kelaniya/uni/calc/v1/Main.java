package com.kelaniya.uni.calc.v1;

/**
 * Created by asankah on 12/6/17.
 */
public class Main {
    public static void main(String[] args) {

        int[] numbers = {25,32}; //todo: numbers should be read from  a text file.

        String operation = args[0];

        int result = 0;

        if ("add".equals(operation)){
            result = numbers[0] + numbers[1];
        }
        else if ("mul".equals(operation)){
            result = numbers[0] * numbers[1];
        }else if ("div".equals(operation)){
            result = numbers[0] / numbers[1];
        }

        System.out.println("The result is " + result);

    }
}
