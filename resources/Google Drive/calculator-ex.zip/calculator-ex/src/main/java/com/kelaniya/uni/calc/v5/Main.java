package com.kelaniya.uni.calc.v5;

import com.kelaniya.uni.calc.v5.operations.Operation;
import com.kelaniya.uni.calc.v5.operations.OperationsFactory;

/**
 * Created by asankah on 12/6/17.
 */
public class Main {
    public static void main(String[] args) {

        NumberRepository numberRepository = new TextFileNumberRespository();
        int[] numbers = numberRepository.read();

        ArgsParser argsParser = new CMDArgsParser(args);
        String operation = argsParser.getOperation();

        double result = 0;

        OperationsFactory operationsFactory = new OperationsFactory();
        Operation operationObj = operationsFactory.getInstance(operation);

        result = operationObj.perform(numbers[0],numbers[1]);

        System.out.println("The result is " + result);
    }
}
