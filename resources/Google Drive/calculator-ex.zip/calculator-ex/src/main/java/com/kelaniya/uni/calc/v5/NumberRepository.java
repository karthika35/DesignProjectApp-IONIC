package com.kelaniya.uni.calc.v5;

/**
 * Created by asankah on 12/13/17.
 */
public interface NumberRepository {
    int[] read();
}
