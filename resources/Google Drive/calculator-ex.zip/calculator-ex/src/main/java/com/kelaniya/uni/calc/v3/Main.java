package com.kelaniya.uni.calc.v3;

/**
 * Created by asankah on 12/6/17.
 */
public class Main {
    public static void main(String[] args) {


        NumberRepository numberRepository = new TextFileNumberRespository();
        int[] numbers = numberRepository.read();


        ArgsParser argsParser = new CMDArgsParser(args);
        String operation = argsParser.getOperation();

        int result = 0;

        if ("add".equals(operation)){
            result = numbers[0] + numbers[1];
        }
        else if ("mul".equals(operation)){
            result = numbers[0] * numbers[1];
        }else if ("div".equals(operation)){
            result = numbers[0] / numbers[1];
        }

        System.out.println("The result is " + result);

    }
}
