package com.kelaniya.uni.calc.v3;

/**
 * Created by asankah on 12/13/17.
 */
public class CMDArgsParser implements ArgsParser {

    private final String[] args;

    public CMDArgsParser(String args[]) {
        this.args = args;
    }

    public String getOperation() {

        if (args.length < 0){
            //todo: handle this case properly
            return "add";
        }

        return args[0];
    }
}
