package com.kelaniya.uni.calc.v6;

import com.kelaniya.uni.calc.v6.operations.Operation;
import com.kelaniya.uni.calc.v6.operations.OperationsFactory;

/**
 * Created by asankah on 12/6/17.
 */
public class Main {
    public static void main(String[] args) {

        NumberRepository numberRepository = new TextFileNumberRespository();
        int[] numbers = numberRepository.read();

        ArgsParser argsParser = new CMDArgsParser(args);
        String operation = argsParser.getOperation();

        double result = 0;

        OperationsFactory operationsFactory = new OperationsFactory();
        Operation operationObj = operationsFactory.getInstance(operation);

        result = operationObj.perform(numbers[0],numbers[1]);

        UI ui = new CmdUI();
        ui.show("The result is " + result);

    }
}
