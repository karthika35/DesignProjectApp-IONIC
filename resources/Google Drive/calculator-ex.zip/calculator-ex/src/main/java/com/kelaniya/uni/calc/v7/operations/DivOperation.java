package com.kelaniya.uni.calc.v7.operations;

/**
 * Created by asankah on 12/13/17.
 */
public class DivOperation implements Operation {
    public double perform(int a, int b) {
        return a/b;
    }
}
