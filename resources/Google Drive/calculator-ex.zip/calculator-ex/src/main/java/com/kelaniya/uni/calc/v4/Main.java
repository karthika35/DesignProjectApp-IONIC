package com.kelaniya.uni.calc.v4;

import com.kelaniya.uni.calc.v4.operations.AddOperation;
import com.kelaniya.uni.calc.v4.operations.DivOperation;
import com.kelaniya.uni.calc.v4.operations.MulOperation;
import com.kelaniya.uni.calc.v4.operations.Opereation;

/**
 * Created by asankah on 12/6/17.
 */
public class Main {
    public static void main(String[] args) {


        NumberRepository numberRepository = new TextFileNumberRespository();
        int[] numbers = numberRepository.read();


        ArgsParser argsParser = new CMDArgsParser(args);
        String operation = argsParser.getOperation();

        double result = 0;

        Opereation opereationObj = null;

        if ("add".equals(operation)){
            opereationObj = new AddOperation();
        }
        else if ("mul".equals(operation)){
            opereationObj = new MulOperation();
        }else if ("div".equals(operation)){
            opereationObj = new DivOperation();
        }

        result = opereationObj.perform(numbers[0],numbers[1]);

        System.out.println("The result is " + result);

    }
}
